<?php

    define('HOST','localhost');
    define('USER','id22007091_brijeshchatrala');
    define('PASS','Bj@241002');
    define('DB','id22007091_brijesh');
    
    $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to connect');

?>