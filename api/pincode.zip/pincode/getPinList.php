<?php
    
    include('connection.php');
    
   
    $office_name = $_POST['office_name'];
    
    
    $q = "select  * from pincode where  office_name = '$office_name'";
    
    $r =  mysqli_query($con,$q);
    $response = array();
    
    while($value = mysqli_fetch_array($r))
    {
        $row["circle_name"] = $value["circle_name"];
        $row["region_name"] = $value["region_name"];
        $row["division_name"] = $value["division_name"];
        $row["office_name"] = $value["office_name"];
        $row["pincode"] = $value["pincode"];
        $row["office_type"] = $value["office_type"];
        $row["delivery"] = $value["delivery"];
        $row["district"] = $value["district"];
        $row["state"] = $value["state"];
        
        array_push($response,$row);
        
        
    }
    echo json_encode($response);
    mysqli_close($con);
    
?>